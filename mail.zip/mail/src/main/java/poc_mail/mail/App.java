package poc_mail.mail;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
      EmailSender.sendMail();
	  EmailReceiver.openMailBox();
    }
}
