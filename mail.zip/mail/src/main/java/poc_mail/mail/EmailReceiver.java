package poc_mail.mail;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.NoSuchProviderException;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.MimeBodyPart;
import javax.mail.search.FlagTerm;

public class EmailReceiver {

	public static void openMailBox() {
		
		try {			
			String protocol="imaps";
			Properties props = new Properties();
			props.setProperty("mail.store.protocol", protocol);
			props.setProperty("mail.imaps.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
			props.setProperty("mail.imaps.socketFactory.fallback", "false");
			props.setProperty("mail.imaps.port", "993");
			props.setProperty("mail.imaps.socketFactory.port", "993");
			                 
			Session session = Session.getDefaultInstance(props, null);
			Store store = session.getStore(protocol);
			store.connect("imap-mail.outlook.com", "fgmp92@outlook.com", "C!elo_372");
			Folder inbox = store.getFolder("Inbox");
			inbox.open(Folder.READ_WRITE);
			
		    Flags seen = new Flags(Flags.Flag.SEEN);
		    FlagTerm unseenFlagTerm = new FlagTerm(seen, false);
		    
		    Message unreadMessages[] = inbox.search(unseenFlagTerm);

		    if (unreadMessages.length == 0) {
		    	System.out.println("No messages found.");
		    } else {
//		    	Message[] messages = inbox.getMessages();
			    
	            for (int i = 0; i < unreadMessages.length; i++) {
	                Message message = unreadMessages[i];
	                Address[] fromAddress = message.getFrom();
	                String from = fromAddress[0].toString();
	                String subject = message.getSubject();
	                String sentDate = message.getSentDate().toString();
	                String contentType = message.getContentType();
	                String messageContent = "";
	                String attachFiles = "";
	 
	                if (contentType.contains("multipart")) {
	                    Multipart multiPart = (Multipart) message.getContent();
	                    int numberOfParts = multiPart.getCount();
	                    
	                    for (int partCount = 0; partCount < numberOfParts; partCount++) {
	                        MimeBodyPart part = (MimeBodyPart) multiPart.getBodyPart(partCount);
	                        if (Part.ATTACHMENT.equalsIgnoreCase(part.getDisposition())) {
	                            String fileName = part.getFileName();
	                            attachFiles += fileName + ", ";
	                            part.saveFile("C:\\workarea" + File.separator + fileName);
	                        } else {
	                            messageContent = part.getContent().toString();
	                        }
	                    }
	                    if (attachFiles.length() > 1) {
	                        attachFiles = attachFiles.substring(0, attachFiles.length() - 2);
	                    }
	                } else if (contentType.contains("text/plain")
	                        || contentType.contains("text/html")) {
	                    Object content = message.getContent();
	                    if (content != null) {
	                        messageContent = content.toString();
	                    }
	                }
	                
	                System.out.println("Message #" + (i + 1) + ":");
	                System.out.println("\t From: " + from);
	                System.out.println("\t Subject: " + subject);
	                System.out.println("\t Sent Date: " + sentDate);
	                System.out.println("\t Message: " + messageContent);
	                System.out.println("\t Attachments: " + attachFiles);
			    
	                }

		    }
		        
            	// disconnect
	            inbox.close(false);
	            store.close();
		    			
		} catch (NoSuchProviderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

}
