package poc_mail.mail;

import org.simplejavamail.email.Email;
import org.simplejavamail.email.EmailBuilder;
import org.simplejavamail.mailer.MailerBuilder;
import org.simplejavamail.mailer.config.TransportStrategy;

public class EmailSender {


	public static void sendMail() {
		
		Email email = EmailBuilder.startingBlank()

		//GMAIL		
//		.from("Felipe Marques", "fgmpmail92@gmail.com")
//	    .to("Felipe Pires", "fgmpmail92@gmail.com")
//	    .withSubject("TESTE E-MAIL")
//	    .withPlainText("Este e-mail é um teste")
//	    .buildEmail();

		//OUTLOOK		
	    .from("Felipe Marques", "fgmp92@outlook.com")
	    .to("Felipe Pires", "fgmpmail92@gmail.com")
	    .withSubject("TESTE E-MAIL")
	    .withPlainText("Este e-mail é um teste")
	    .buildEmail();

		
		
		//GMAIL
//		MailerBuilder.withSMTPServer("smtp.gmail.com", 465, "fgmpmail92@gmail.com", "C!elo_372")
//		.withTransportStrategy(TransportStrategy.SMTPS)
//		.buildMailer()
//		.sendMail(email);
		
		//OUTLOOK
		MailerBuilder.withSMTPServer("smtp-mail.outlook.com", 587, "fgmp92@outlook.com", "C!elo_372")
		.withTransportStrategy(TransportStrategy.SMTP)
		.buildMailer()
		.sendMail(email);
		
		
	}

	
	
}
